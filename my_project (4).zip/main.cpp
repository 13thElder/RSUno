#include <iostream>
#include "LinkedList.h"

template <class T>
LinkedList<T> function1(LinkedList<T> a, LinkedList<T> b)
{
    LinkedList<T> result;

    int sizeA = a.numNodes();
    int sizeB = b.numNodes();

    int i = 0, j = 0;

    while (i < sizeA && j < sizeB)
    {
        if (a.getValueAt(i) < b.getValueAt(j))
        {
            result.insertEnd(a.getValueAt(i));
            i++;
        }
        else
        {
            result.insertEnd(b.getValueAt(j));
            j++;
        }
    }

    while (i < sizeA)
    {
        result.insertEnd(a.getValueAt(i));
        i++;
    }

    while (j < sizeB)
    {
        result.insertEnd(b.getValueAt(j));
        j++;
    }

    return result;
}

template <class T>
bool function2(LinkedList<T> a, LinkedList<T> b)
{
    if (a.numNodes() != b.numNodes())
        return false;

    for (int i = 0; i < a.numNodes(); i++)
    {
        if (a.getValueAt(i) != b.getValueAt(i))
            return false;
    }

    return true;
}

int main()
{
    LinkedList<int> list1;
    LinkedList<int> list2;

    list1.insertEnd(1);
    list1.insertEnd(3);
    list1.insertEnd(5);

    list2.insertEnd(2);
    list2.insertEnd(4);
    list2.insertEnd(6);

    std::cout << "List 1: ";
    list1.displayList();

    std::cout << "List 2: ";
    list2.displayList();

    LinkedList<int> merged = function1(list1, list2);

    std::cout << "Merged List: ";
    merged.displayList();

    if (function2(list1, list2))
        std::cout << "Lists are equal\n";
    else
        std::cout << "Lists are NOT equal\n";

    return 0;
}