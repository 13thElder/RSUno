#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <iostream>

template <class T>
class LinkedList
{
private:
    struct ListNode
    {
        T value;
        ListNode* next;
    };

    ListNode* head;

public:
    LinkedList()
    {
        head = nullptr;
    }

    ~LinkedList()
    {
        ListNode* nodePtr = head;
        while (nodePtr)
        {
            ListNode* garbage = nodePtr;
            nodePtr = nodePtr->next;
            delete garbage;
        }
    }

    void appendNode(T num)
    {
        ListNode* newNode = new ListNode;
        newNode->value = num;
        newNode->next = nullptr;

        if (!head)
            head = newNode;
        else
        {
            ListNode* nodePtr = head;
            while (nodePtr->next)
                nodePtr = nodePtr->next;

            nodePtr->next = newNode;
        }
    }

    void insertNode(T num)
    {
        ListNode* newNode = new ListNode;
        newNode->value = num;

        if (!head || head->value >= num)
        {
            newNode->next = head;
            head = newNode;
        }
        else
        {
            ListNode* nodePtr = head;

            while (nodePtr->next && nodePtr->next->value < num)
                nodePtr = nodePtr->next;

            newNode->next = nodePtr->next;
            nodePtr->next = newNode;
        }
    }

    void deleteNode(T num)
    {
        ListNode* nodePtr = head;
        ListNode* previous = nullptr;

        if (!head)
            return;

        if (head->value == num)
        {
            nodePtr = head->next;
            delete head;
            head = nodePtr;
        }
        else
        {
            while (nodePtr && nodePtr->value != num)
            {
                previous = nodePtr;
                nodePtr = nodePtr->next;
            }

            if (nodePtr)
            {
                previous->next = nodePtr->next;
                delete nodePtr;
            }
        }
    }

    void displayList()
    {
        ListNode* nodePtr = head;

        while (nodePtr)
        {
            std::cout << nodePtr->value << " ";
            nodePtr = nodePtr->next;
        }

        std::cout << std::endl;
    }

    int numNodes()
    {
        int count = 0;
        ListNode* nodePtr = head;

        while (nodePtr)
        {
            count++;
            nodePtr = nodePtr->next;
        }

        return count;
    }

    int search(T val)
    {
        int pos = 0;
        ListNode* nodePtr = head;

        while (nodePtr)
        {
            if (nodePtr->value == val)
                return pos;

            pos++;
            nodePtr = nodePtr->next;
        }

        return -1;
    }

    T getValueAt(int position)
    {
        int index = 0;
        ListNode* nodePtr = head;

        while (nodePtr)
        {
            if (index == position)
                return nodePtr->value;

            nodePtr = nodePtr->next;
            index++;
        }

        return T();
    }

    T getTotal()
    {
        T total = 0;
        ListNode* nodePtr = head;

        while (nodePtr)
        {
            total += nodePtr->value;
            nodePtr = nodePtr->next;
        }

        return total;
    }

    T getAverage()
    {
        int count = numNodes();
        if (count == 0)
            return 0;

        return getTotal() / count;
    }

    T getLargest()
    {
        ListNode* nodePtr = head;
        T largest = nodePtr->value;

        while (nodePtr)
        {
            if (nodePtr->value > largest)
                largest = nodePtr->value;

            nodePtr = nodePtr->next;
        }

        return largest;
    }

    int getLargestPosition()
    {
        ListNode* nodePtr = head;
        T largest = nodePtr->value;

        int pos = 0;
        int largestPos = 0;

        while (nodePtr)
        {
            if (nodePtr->value > largest)
            {
                largest = nodePtr->value;
                largestPos = pos;
            }

            nodePtr = nodePtr->next;
            pos++;
        }

        return largestPos;
    }

    T getSmallest()
    {
        ListNode* nodePtr = head;
        T smallest = nodePtr->value;

        while (nodePtr)
        {
            if (nodePtr->value < smallest)
                smallest = nodePtr->value;

            nodePtr = nodePtr->next;
        }

        return smallest;
    }

    int getSmallestPosition()
    {
        ListNode* nodePtr = head;
        T smallest = nodePtr->value;

        int pos = 0;
        int smallestPos = 0;

        while (nodePtr)
        {
            if (nodePtr->value < smallest)
            {
                smallest = nodePtr->value;
                smallestPos = pos;
            }

            nodePtr = nodePtr->next;
            pos++;
        }

        return smallestPos;
    }

    void insertFront(T val)
    {
        ListNode* newNode = new ListNode;
        newNode->value = val;
        newNode->next = head;
        head = newNode;
    }

    void insertEnd(T val)
    {
        appendNode(val);
    }

    T deleteFront()
    {
        if (!head)
            return T();

        ListNode* temp = head;
        T val = head->value;

        head = head->next;
        delete temp;

        return val;
    }

    T deleteLast()
    {
        if (!head)
            return T();

        if (!head->next)
        {
            T val = head->value;
            delete head;
            head = nullptr;
            return val;
        }

        ListNode* nodePtr = head;

        while (nodePtr->next->next)
            nodePtr = nodePtr->next;

        T val = nodePtr->next->value;
        delete nodePtr->next;
        nodePtr->next = nullptr;

        return val;
    }
};

#endif